#Ask for user name
name = input("please enter your name: ")
#Greet the user
print("Hello, " + name + "!")

#Ask for user age
age = input("please enter your age: ")
#Greet the user
print("Hello, " + name + "! You are " + age + " years old.")
#Ask for user city
city = input("please enter your city: ")